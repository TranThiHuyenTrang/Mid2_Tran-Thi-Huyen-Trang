<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateRoom1Table extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('_room1', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('image');
            $table->string('typeroom');
            $table->string('number');
            $table->string('area');
            $table->tinyint('price');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('_room1');
    }
}

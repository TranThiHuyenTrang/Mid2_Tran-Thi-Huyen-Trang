<?php

use Illuminate\Database\Seeder;

class roomSeed extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker\Factory::create();
        for($i=0;$i<10;$i++){
            DB::table('_room1')->insert([
                'name'=>$faker->name,
                'image'=>Str::random(10),
                'typeroom'=>$faker->text($maxNbChars = 10),
                'number'=>$faker->text($maxNbChars = 10),
                'area'=>$faker->text($maxNbChars = 10),
                'price'=>$faker->randomNumber(2)
            ]);
        }
    }
}

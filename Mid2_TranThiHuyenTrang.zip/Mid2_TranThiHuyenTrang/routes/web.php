<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('index',[
'as'=>'trang-chu',
'uses'=>'PageController@getIndex'
]);

Route::get('gioi_thieu',[
'as'=>'about',
'uses'=>'PageController@getAbout'
]);
Route::get('lien_he',[
'as'=>'lienhe',
'uses'=>'PageController@getLienhe'
]);

Route::get('chi-tiet-san-pham/{id}',[
'as'=>'chitietsanpham',
'uses'=>'PageController@getChitiet'
]);

Route::get('loai-san-pham/{type}',[
'as'=>'loaisanpham',
'uses'=>'PageController@getLoaiSp'
]);

Route::get('add-to-cart/{id}',[
'as'=>'themgiohang',
'uses'=>'PageController@getAddtoCart'
]);

Route::get('del-cart/{id}',[
	'as'=>'xoagiohang',
	'uses'=>'PageController@getDelItemCart'
]);

Route::get('da-thang',[
'as'=>'dathang',
'uses'=>'PageController@getCheckout'
]);
Route::post('da-thang',[
'as'=>'dathang',
'uses'=>'PageController@postCheckout'
]);

Route::get('thongbao', 'PageController@notice');

Route::get('dang-nhap',[
	'as'=>'login',
	'uses'=>'PageController@getLogin'
]);
Route::post('dang-nhap',[
	'as'=>'login',
	'uses'=>'PageController@postLogin'
]);

Route::get('dang-ki',[
	'as'=>'signin',
	'uses'=>'PageController@getSignin'
]);

Route::post('dang-ki',[
	'as'=>'signin',
	'uses'=>'PageController@postSignin'
]);
Route::get('dang-ki',[
	'as'=>'signin',
	'uses'=>'PageController@getSignin'
]);
Route::get('tim-kiem',[
	'as'=>'search',
	'uses'=>'PageController@getSearch'
]);
// admin
Route::get('indexadmin',[
'as'=>'trang-chu-admin',
'uses'=>'PageController@getIndexAdmin'
]);
Route::get('xemsanpham/delete/{id}',[
'as'=>'xoasanpham',
'uses'=>'PageController@deleteProduct'
]);
Route::get('xemsanpham/edit/{id}',[
'as'=>'editsanpham',
'uses'=>'PageController@deleteProduct'
]);
Route::get('them-sp',[
	'as'=>'themsanp',
	'uses'=>'PageController@insertProductPage'
]);
Route::post('them-sp',[
	'as'=>'themsanp',
	'uses'=>'PageController@insertProduct'
]);
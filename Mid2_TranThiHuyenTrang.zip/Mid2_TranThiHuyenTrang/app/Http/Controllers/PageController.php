<?php

namespace App\Http\Controllers;
use App\SildeModel;
use App\Product;
use App\Cart;
use App\TypeProduct;
use App\Customer;
use App\Bill;
use App\User;
use App\BillDetail;
use Session;
use Hash;
use Auth;
use App\Http\Requests\CustomerRequest;
use App\Http\Requests\SigninRequest;
use DB;

use Illuminate\Http\Request;

class PageController extends Controller
{
    public function getIndex(){
    	$slide = SildeModel::all();
    	// return view('page.trangchu',compact('slide'));
    	$new_product = Product::where('new',1)->paginate(4);
    	$sale_product = Product::where('new',0)->paginate(4);
    	return view('page.trangchu',compact('slide','new_product','sale_product'));
    }
    public function getLoaiSp($type){
    	$sp_theoloai = Product::where('id_type',$type)->limit(3)->get();
    	$sp_khac= Product::where('id_type','<>',$type)->limit(3)->get();
    	$loai= TypeProduct::all();
    	$loai_sp=TypeProduct::where('id',$type)->first();
    	return view('loai_sanpham',compact('sp_theoloai','sp_khac','loai','loai_sp'));
    }

    public function getChitiet(Request $req){
    	$sanpham = Product::where('id',$req->id)->first();
    	$sp_tuongtu = Product::where('id_type',$sanpham->id_type)->paginate(4);
    	$sp_new = Product::where('promotion_price','=',0)->paginate(4);
    	return view('page.chitiet_sanpham',compact('sanpham','sp_tuongtu'));

    }
     public function getAddtoCart(Request $req,$id){
        $product = Product::find($id);
        $oldCart = Session('cart')?Session::get('cart'):null;
        $cart = new Cart($oldCart);
        $cart->add($product, $id);
        $req->session()->put('cart',$cart);
        return redirect()->back();
    }
       public function getDelItemCart($id){
        $oldCart = Session::has('cart')?Session::get('cart'):null;
        $cart = new Cart($oldCart);
        $cart->removeItem($id);
        if(count($cart->items)>0){
            Session::put('cart',$cart);
        }
        else{
            Session::forget('cart');
        }
        return redirect()->back();
    }

    public function getCheckout(){
    	$oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        return view('page.dathang')->with(['cart'=>$oldCart,'product_cart'=>$cart->items,
        'totalPrice'=>$cart->totalPrice,'totalQty'=>$cart->totalQty]);
     
    }
    public function postCheckout(CustomerRequest $req){
        $cart = Session::get('cart');
        $customer = new Customer;
        $customer->name = $req->name;
        $customer->gender = $req->gender;
        $customer->email = $req->email;
        $customer->address = $req->address;
        $customer->phone_number = $req->phone;
        $customer->note = $req->notes;
        $customer->save();

        $bill = new Bill;
        $bill->id_customer = $customer->id;
        $bill->date_order = date('Y-m-d');
        $bill->total = $cart->totalPrice;
        $bill->payment = $req->payment_method;
        $bill->note = $req->notes;
        $bill->save();

        foreach ($cart->items as $key => $value) {
            $bill_detail = new BillDetail;
            $bill_detail->id_bill = $bill->id;
            $bill_detail->id_product = $key;
            $bill_detail->quantity = $value['qty'];
            $bill_detail->unit_price = ($value['price']/$value['qty']);
            $bill_detail->save();
        }
        Session::forget('cart');
        return redirect()->action('PageController@getIndex');

    }
    public function getLogin(){
        return view('page.login');
    }
    // public function postLogin(Request $req){

    //     $username= $req->username;
    //     $username = $req->password;
    //     $user = User::where('full_name' =>$username, 'password' =>$username);
        
        //     return redirect()->getIndex();
        
        // else
        //     return redirect()->back();
        
    // }

     public function getSignin(){
        return view('page.dangki');
    }
    public function postSignin(SigninRequest $req){
        $user = new User();
        $user->full_name = $req->fullname;
        $user->email = $req->email;
        // $user->password = Hash::make($req->password);
        $user->password = $req->password;
        $user->phone = $req->phone;
        $user->address = $req->address;
        $user->save();
        return redirect()->route('login')->with('thanhcong','Tạo tài khoản thành công');
    }
    public function getAbout(){
        return view('page.aboutus');
    }
    public function getLienhe(){
        return view('page.lienhe');
    }
    public function getSearch(Request $req){
        $slide = SildeModel::all();
        $find_product = Product::where('name', 'like', '%' . $req->key . '%')->paginate(4);
         return view('page.search',compact('find_product','slide'));
    }
    public function getIndexAdmin(){
        $slide = SildeModel::all();
        $new_product = Product::where('new',1)->paginate(4);
        $sale_product = Product::where('new',0)->paginate(4);
        return view('Admin.pageadmin',compact('slide','new_product','sale_product'));
    }
    public function deleteProduct($id){
        DB::table('products')->where ('id','=',$id)->delete();
        return redirect()->action('PageController@getIndexAdmin');
    }

    public function hienthi(){
        return view('Admin.pageadmin');
    
    }
    public function insertProductPage(){
        return view("Admin.insertProduct");
    }
    public function insertProduct(Request $request){
        $sp= new Product;
        $sp ->name=$request->name;
        $sp ->description=$request->mota;
        $sp ->id_type=$request->idtype;
        $sp->unit_price=$request->giagoc;
        $sp->promotion_price=$request->khuyenmai;
        $sp->unit=$request->unit;
        $sp->new=$request->status;
        $file_name = $request->file('myFile')->getClientOriginalName();
        $request->file('myFile')->move('source/image/product/',$file_name);
        $sp ->image= $file_name;
        $sp->save();
        return redirect()->action('PageController@getIndexAdmin');
    }

}

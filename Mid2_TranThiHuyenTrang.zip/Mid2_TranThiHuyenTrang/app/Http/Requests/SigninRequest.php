<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class SigninRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'phone'=>'required',
            'email'=>'required',
            'address'=>'required',
            'password'=>'required',
            'fullname'=>'required',
            're_password'=>'required|same:password'
        ];
    }
    public function messages(){
        return [
            'fullname.required'=> 'Vui lòng nhập tên của bạn',
            'email.required'=> 'Vui lòng nhập email của bạn',
            'phone.required'=> 'Vui lòng nhập số điện thoại của bạn',
            'address.required'=> 'Vui lòng nhập địa chỉ của bạn',
            'password.required'=> 'Vui lòng nhập mật khẩu',
            're_password.required'=> 'Vui lòng nhập lại mật khẩu',
            're_password.same:password'=> ''

        ];
    }
}

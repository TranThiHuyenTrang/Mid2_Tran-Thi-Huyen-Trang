<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class roomModel extends Model
{
    protected $table='_room1';
}

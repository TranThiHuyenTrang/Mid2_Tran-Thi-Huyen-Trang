<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<meta name="Description" content="Enter your description here"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
<link rel="stylesheet" href="Css/insertRoom.css">
<title>Insert room</title>
</head>
<body>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.1/umd/popper.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/js/bootstrap.min.js"></script>

<div class="container register">
    <div class="row">
        <div class="col-md-3 register-left">
            <img src="https://image.ibb.co/n7oTvU/logo_white.png" alt=""/>
            <h3>Insert Room</h3>
        </div>

        <div class="col-md-9 register-right">
            <div class="tab-content" id="myTabContent">
                <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                    <h3 class="register-heading">Insert Room</h3>
                    <form role="form" class="form-horizontal" method="post" action="" enctype="multipart/form-data">
                    <div class="request">
                        <?php echo $__env->make('blocks.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>" />
                    <div class="row register-form">
                    <div class="col-md-6">
                            <div class="form-group">
                                <input type="text"name="name" class="form-control" placeholder="Room Name *" value="" />
                            </div>
                            <div class="form-group">
                                <input type="text"name="typeroom" class="form-control" placeholder="Type room *" value="" />
                            </div>
                            <div class="form-group">
                                <input type="text"name="number" class="form-control" placeholder="Number *" value="" />
                            </div>
                        </div>
                        <div class="col-md-6">
                        <div class="form-group">
                                <input type="text"name="area" class="form-control" placeholder=" Area *" value="" />
                            </div>
                            <div class="form-group">
                                <input type="text"name="price" class="form-control" placeholder=" Price *" value="" />
                            </div>
                            <div class="form-group">
                                <input type="file" name="myFile" id="myFile">
                            </div>
                      
                            <form method="post" action="">
                                <input type="submit" class="btnRegister"  value="Insert"/>    
                            </form>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\ktTranThiHuyenTrang\resources\views/Admin/insertRom.blade.php ENDPATH**/ ?>
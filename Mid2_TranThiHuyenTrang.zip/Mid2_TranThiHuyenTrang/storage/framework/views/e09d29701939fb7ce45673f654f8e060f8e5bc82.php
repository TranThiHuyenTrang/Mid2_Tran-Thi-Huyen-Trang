
<?php $__env->startSection('content'); ?>
	
	<div class="container">
		<div id="content">
			<form action="<?php echo e(route('themsanp')); ?>"  enctype="multipart/form-data" method="POST" class="beta-form-checkout">
			<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
				<div class="row">
					<div class="col-sm-3"></div>
					<div class="col-sm-6">
						<h4>Thêm sản phẩm</h4>
						<div class="space20">&nbsp;</div>
						<div class="form-group">
                            <label for="name" class="cols-sm-2 control-label">Nhập tên sản phẩm</label>
                            <div class="cols-sm-10">
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-lock fa-lg" aria-hidden="true"></i></span>
                                    <input type="text" class="form-control" name="name" id="" placeholder="Nhập tên sản phẩm" />
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="password" class="cols-sm-2 control-label">Chọn loại sản phẩm</label>
                            <div class="form-block">
                                
                                <input id="gender" type="radio" class="input-radio" name="idtype" value="1" style="width: 10%"><span style="margin-right: 10%">1</span>     
                                <input id="gender" type="radio" class="input-radio" name="idtype" value="2" style="width: 10%"><span style="margin-right: 10%">2</span>    
                                <input id="gender" type="radio" class="input-radio" name="idtype" value="3" style="width: 10%"><span style="margin-right: 10%">3</span>    
                                <input id="gender" type="radio" class="input-radio" name="idtype" value="4" style="width: 10%"><span style="margin-right: 10%">4</span>
                            </div>
                        </div>
                         <div class="form-group">
                            <label for="email" class="cols-sm-2 control-label">Nhập mô tả</label>
                            <div class="cols-sm-10">
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-lock fa-lg" aria-hidden="true"></i></span>
                                    <input type="text" class="form-control" name="mota" id="" placeholder="Nhập mô tả" />
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="password" class="cols-sm-2 control-label">Nhập giá gốc</label>
                            <div class="cols-sm-10">
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-lock fa-lg" aria-hidden="true"></i></span>
                                    <input type="text" class="form-control" name="giagoc" id="" placeholder="Nhập giá gốc" />
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="password" class="cols-sm-2 control-label">Nhập giá khuyến mãi</label>
                            <div class="cols-sm-10">
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-lock fa-lg" aria-hidden="true"></i></span>
                                    <input type="text" class="form-control" name="khuyenmai" id="" placeholder="Nhập giá khuyến mãi" />
                                </div>
                            </div>
                        </div>
						 <div class="form-group">
                            <label for="password" class="cols-sm-2 control-label">Chèn ảnh</label>
                            <div class="cols-sm-10">
                                <div class="input-group">
                                    <input type="file" class="form-control" name="myFile" id="myFile">
                                </div>
                            </div>
                        </div>
                         <div class="form-group">
                            <label for="password" class="cols-sm-2 control-label">Nhập unit</label>
                            <div class="cols-sm-10">
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-lock fa-lg" aria-hidden="true"></i></span>
                                    <input type="text" class="form-control" name="unit" id="" placeholder="Nhập unit" />
                                </div>
                            </div>
                        </div>
                         <div class="form-group">
                            <label for="password" class="cols-sm-2 control-label">Chọn trạng thái</label>
                            <div class="form-block">
                                <input id="gender" type="radio" class="input-radio" name="status" value="0"  style="width: 10%"><span style="margin-right: 10%">0</span>
                                <input id="gender" type="radio" class="input-radio" name="status" value="1" style="width: 10%"><span>1</span>         
                            </div>
                        </div>
                            <div class="form-block">
                                <button type="submit" class="btn btn-primary">Hoàn tất</button>
                            </div> 
					</div>
					<div class="col-sm-3"></div>
				</div>
			</form>
		</div> <!-- #content -->
	</div> <!-- .container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ktTranThiHuyenTrang\resources\views/Admin/insertProduct.blade.php ENDPATH**/ ?>
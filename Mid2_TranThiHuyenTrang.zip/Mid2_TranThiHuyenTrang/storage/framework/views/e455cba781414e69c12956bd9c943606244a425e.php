
<?php $__env->startSection('content'); ?>
<div class="inner-header">
    <div class="container">
        <div class="pull-left">
            <h6 class="inner-title">Sản phẩm <?php echo e($loai_sp->name); ?></h6>				
        </div>
<!--         <div class="pull-right">
            <div class="beta-breadcrumb font-large">
                <a href="<?php echo e(route('trang-chu')); ?>">Home</a> / <span>Sản phẩm</span>
            </div>
        </div> -->
        <div class="clearfix"></div>
    </div>
</div>
<div class="container">
    <div id="content" class="space-top-none">
        <div class="main-content">
            <div class="space60">&nbsp;</div>
            <div class="row">
                <div class="col-sm-3">
                    <!-- Hienthi menu ngang -->
                    <ul class="aside-menu">
                        <?php $__currentLoopData = $loai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(route('loaisanpham',$loai->id)); ?>"><?php echo e($loai->name); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <div class="col-sm-9">
                    <div class="beta-products-list">
                        <h4>Sản phẩm</h4>
                        <div class="beta-products-details">
                            
                            <div class="clearfix"></div>
                        </div>
                        <div class="row">
                            <?php $__currentLoopData = $sp_theoloai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theoloai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-sm-4">
                                <div class="single-item">
                                    <div class="single-item-header">
                                        <a href=""><img src="source/image/product/<?php echo e($theoloai->image); ?> " height="220px" alt=""></a>
                                    </div>
                                    <div class="single-item-body">
                                        <p class="single-item-title"><?php echo e($theoloai->name); ?></p>
                                        <p class="single-item-price">
                                            <?php if($theoloai->promotion_price == 0): ?>
                                                <span class="flash-sale"><?php echo e($theoloai->unit_price); ?> đồng</span>
                                            <?php else: ?> 
                                                <span class="flash-del"><?php echo e($theoloai->unit_price); ?> đồng</span>
                                                <span class="flash-sale"><?php echo e($theoloai->promotion_price); ?> đồng</span>
                                            <?php endif; ?>
                                        </p>
                                    </div>
                                    <div class="single-item-caption">
                                        <a class="add-to-cart pull-left" href="<?php echo e(route('themgiohang',$theoloai->id)); ?>"><i class="fa fa-shopping-cart"></i></a>
                                        <a class="beta-btn primary" href="<?php echo e(route('chitietsanpham',$theoloai->id)); ?>">Details <i class="fa fa-chevron-right"></i></a>
                                        <div class="clearfix"></div>
                                    </div>
                                </div>
                            </div> 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>               
                        </div>
                    <div class="beta-products-list">
                        <h4>Sản phẩm khác</h4>
                        <div class="beta-products-details">
                            <p class="pull-left"></p>
                            <div class="clearfix"></div>
                        </div>
                        <div class="row">
                            <?php $__currentLoopData = $sp_khac; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $khac): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-sm-4">
                                <div class="single-item">
                                    <div class="single-item-header">
                                        <a href=""><img src="source/image/product/<?php echo e($khac->image); ?>"  alt="" height="220px"></a>
                                    </div>
                                    <div class="single-item-body">
                                        <p class="single-item-title">Sample Woman Top</p>
                                        <p class="single-item-price">
                                            <?php if($theoloai->promotion_price == 0): ?>
                                                <span class="flash-sale"><?php echo e($theoloai->unit_price); ?> đồng</span>
                                            <?php else: ?> 
                                                <span class="flash-del"><?php echo e($theoloai->unit_price); ?> đồng</span>
                                                <span class="flash-sale"><?php echo e($theoloai->promotion_price); ?> đồng</span>
                                            <?php endif; ?>
                                        </p>
                                    </div>
                                    <div class="single-item-caption">
                                        <a class="add-to-cart pull-left" href="shopping_cart.html"><i class="fa fa-shopping-cart"></i></a>
                                        <a class="beta-btn primary" href="<?php echo e(route('chitietsanpham',$khac->id)); ?>l">Details <i class="fa fa-chevron-right"></i></a>
                                        <div class="clearfix"></div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                      
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ktTranThiHuyenTrang\resources\views/loai_sanpham.blade.php ENDPATH**/ ?>
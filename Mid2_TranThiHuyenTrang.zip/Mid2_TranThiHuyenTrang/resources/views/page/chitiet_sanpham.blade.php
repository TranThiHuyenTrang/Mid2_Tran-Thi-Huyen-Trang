@extends('master')
@section('content')
<div class="inner-header">
    <div class="container">
        <div class="pull-left">
            <h6 class="inner-title">Sản phẩm {{$sanpham->name}}</h6>
        </div>
        <div class="clearfix"></div>
    </div>
</div>

<div class="container">
    <div id="content">
        <div class="row">
            <div class="col-sm-9">
                <div class="row">
                    <div class="col-sm-4">
                        <img src="source/image/product/{{$sanpham->image}} " height="220px" alt="">
                    </div>
                    <div class="col-sm-8">
                        <div class="single-item-body">
                             <h6 class="inner-title">{{$sanpham->name}}</h6><br><br>
                            <p class="single-item-price">
                                @if($sanpham->promotion_price == 0)
                                <span class="flash-sale">{{$sanpham->unit_price}} đồng</span>
                            @else 
                                <span class="flash-del">{{$sanpham->unit_price}} đồng</span>
                                <span class="flash-sale">{{$sanpham->promotion_price}} đồng</span>
                            @endif
                            </p>
                        </div>
                        <div class="single-item-desc">
                            <p>{{$sanpham->description}}</p>
                        </div>
                        <div class="space20">&nbsp;</div>

                        <p>Options:</p>
                        <div class="single-item-options">
                            <select class="wc-select" name="size">
                                <option>Size</option>
                                <option value="XS">XS</option>
                                <option value="S">S</option>
                                <option value="M">M</option>
                                <option value="L">L</option>
                                <option value="XL">XL</option>
                            </select>
                            <select class="wc-select" name="color">
                                <option>Color</option>
                                <option value="Red">Red</option>
                                <option value="Green">Green</option>
                                <option value="Yellow">Yellow</option>
                                <option value="Black">Black</option>
                                <option value="White">White</option>
                            </select>
                            <select class="wc-select" name="color">
                                <option>Qty</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select>
                            <a class="add-to-cart" href="{{route('themgiohang',$sanpham->id)}}"><i class="fa fa-shopping-cart"></i></a>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>
                <div class="space40">&nbsp;</div>
            </div>
            
        </div>
    </div> <!-- #content -->
</div> <!-- .container -->
    <div class="beta-products-list">
        <h4>Sản phẩm tương tự</h4>
        <div class="space40">&nbsp;</div>
        <div class="row">
            @foreach($sp_tuongtu as $tuongtu)
            <div class="col-sm-3">
                <div class="single-item">

                    <div class="single-item-header">
                        <a href="{{route('chitietsanpham',$tuongtu->id)}}"><img src="source/image/product/{{$tuongtu->image}}" alt=""height="220px;"></a>
                    </div>
                    <div class="single-item-body">
                        <p class="single-item-title">{{$tuongtu->name}}</p>
                        <p class="single-item-price">
                            <span class="flash-del">{{$tuongtu->unit_price}}đồng</span>
                            <span class="flash-sale">{{$tuongtu->promotion_price}}đồng</span>
                        </p>
                    </div>
                    <div class="single-item-caption">
                        <a class="add-to-cart pull-left" href="{{route('themgiohang',$tuongtu->id)}}"><i class="fa fa-shopping-cart"></i></a>
                        <a class="beta-btn primary" href="{{route('chitietsanpham',$tuongtu->id)}}">Details <i class="fa fa-chevron-right"></i></a>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
        
            @endforeach

        </div>

        <div class="row">{{$sp_tuongtu->links()}}</div>
    </div>
  
@endsection
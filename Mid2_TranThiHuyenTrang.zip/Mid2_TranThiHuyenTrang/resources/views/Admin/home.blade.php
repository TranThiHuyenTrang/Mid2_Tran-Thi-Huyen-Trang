<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<meta name="Description" content="Enter your description here"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
<link rel="stylesheet" href="Css/romCss.css">
<link rel="stylesheet" href="Css/header.css">
<title>Hotel</title>
</head>
<body>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.1/umd/popper.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/js/bootstrap.min.js"></script>
<!-- header -->

<div class="bloc l-bloc" id="nav-bloc">
	<div class="container">
		<nav class="navbar row">
			<div class="navbar-header">
                <a class="navbar-brand" href="#"></a>
                <img class="img-fluid" src="Img/logo.png" alt="" style="width: 100px;height: 100px">
				<button id="nav-toggle" type="button" class="ui-navbar-toggle navbar-toggle" data-toggle="collapse" data-target=".navbar-1">
					<span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span>
				</button>
            </div>
                <div style="display: flex;justify-content: space-between;"> 
                    <img class="img-fluid" src="Img/home.png" alt="" style="width: 30px;height: 30px">
                    <a href="#">TRANG CHỦ</a>
                </div>
                <div style="display: flex;justify-content: space-between;"> 
                    <img class="img-fluid" src="Img/sao.png" alt="" style="width: 30px;height: 30px">
                    <a href="#">PHÒNG & MỨC GIÁ</a>
                </div>
                <div style="display: flex;justify-content: space-between;"> 
                    <img class="img-fluid" src="Img/dh.png" alt="" style="width: 30px;height: 30px">
                    <a href="#">ĐẶT PHÒNG</a>
                </div>
                <div style="display: flex;justify-content: space-between;"> 
                    <img class="img-fluid" src="Img/img.png" alt="" style="width: 30px;height: 30px">
                    <a href="#">HÌNH ẢNH</a>
                </div>
                <div style="display: flex;justify-content: space-between;"> 
                    <img class="img-fluid" src="Img/cham.png" alt="" style="width: 30px;height: 30px">
                    <a href="#">GIỚI THIỆU</a>
                </div>
                <div style="display: flex;justify-content: space-between;"> 
                    <img class="img-fluid" src="Img/user.png" alt="" style="width: 30px;height: 30px">
                    <a href="#">LIÊN HỆ</a>
                </div>     
		</nav>
	</div>
</div>
<!--  -->

<form method="" action="themphong">
    <button class="btn" style="color:red">
        Thêm room
    </button>
</form>
    <div class="row">
    @foreach ($products as $product)
        <div class="col-sm-6 col-md-4"style="padding: 50px " >
            <div class="product-grid">
                <div class="product-image">
                    <a href="#">
                        <img class="pic-1" src="{{$product['image']}}">
                    </a>
                </div>
                <div class="product-content">
                <div style="display: flex;justify-content: space-between;"> 
                    <h3 class="price"><b>{{$product['typeroom']}}</b></h3>
                    <div></div>
                </div>     
                <div style="display: flex;justify-content: space-between;"> 
                    <h3 class="title"> PHÒNG </h3>
                    <div class="title" >{{$product['name']}}</div> 
                </div>
                <p style="border-bottom: 2px solid #C0C0C0; "> </p>
                <div style="display: flex;justify-content: space-between;"> 
                <h3 class="title">CHỖ NGHỈ </h3>
                    <h3 class="title">{{$product['number']}}</h3>
                </div>
                <p style="border-bottom: 2px solid #C0C0C0; "> </p>
                <div style="display: flex;justify-content: space-between;"> 
                    <h3 class="title">KÍCH THƯỚC</h3>
                    <h3 class="title">{{$product['area']}}</h3>
                </div>
                <p style="border-bottom: 2px solid #C0C0C0; "> </p>
                <div style="display: flex;justify-content: space-between;"> 
                    <h3 class="title">GIÁ PHÒNG</h3>
                    <h3 class="title" style="color:#110000">{{$product['price']}}</h3>
                </div>
                <p style="border-bottom: 2px solid #C0C0C0; "> </p>  
                <div style="display: flex;justify-content: space-between;"> 
                    <h3 class="title">XEM</h3>
                    <button class="btn"name="xoa"  style="margin-left: 40px; color:#FF9966">Đặt phòng</button>
                </div>  
            </div>
            </div>
        </div>
</br> </br> </br>
        @endforeach
        </div>
    </div>
<hr>
</body>
</html>